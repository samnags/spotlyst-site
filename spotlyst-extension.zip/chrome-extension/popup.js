// Spotlyst Chrome Extension — Popup
// Handles OTP auth and triggers export

const SUPABASE_URL = "https://ozedrhggdyenuatuvybc.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im96ZWRyaGdnZHllbnVhdHV2eWJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1ODQ5MjEsImV4cCI6MjA4ODE2MDkyMX0.WvAhTNIPGQUOWO-gdtunjj2cd5TUu0ZOgC6y_tyaIho";
const EXTENSION_VERSION = chrome.runtime.getManifest().version;

// ── Analytics ────────────────────────────────────────────
async function trackEvent(eventName, properties = {}) {
  try {
    const stored = await chrome.storage.local.get(["sb_session"]);
    const session = stored.sb_session;
    if (!session) return;

    await fetch(`${SUPABASE_URL}/rest/v1/analytics_events`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        Prefer: "return=minimal",
      },
      body: JSON.stringify({
        user_id: session.user.id,
        email: session.user.email,
        event_name: eventName,
        properties: {
          ...properties,
          platform: "chrome_extension",
          extension_version: EXTENSION_VERSION,
        },
      }),
    }).catch(() => {});
  } catch {}
}

// ── DOM refs ──────────────────────────────────────────────
const authEmailScreen = document.getElementById("auth-email-screen");
const authCodeScreen = document.getElementById("auth-code-screen");
const mainScreen = document.getElementById("main-screen");
const emailForm = document.getElementById("email-form");
const codeForm = document.getElementById("code-form");
const emailInput = document.getElementById("email");
const otpCodeInput = document.getElementById("otp-code");
const sendCodeBtn = document.getElementById("send-code-btn");
const verifyBtn = document.getElementById("verify-btn");
const resendBtn = document.getElementById("resend-btn");
const changeEmailBtn = document.getElementById("change-email-btn");
const sentToEmail = document.getElementById("sent-to-email");
const emailError = document.getElementById("email-error");
const codeError = document.getElementById("code-error");
const userEmail = document.getElementById("user-email");
const signOutBtn = document.getElementById("sign-out-btn");
const notOnList = document.getElementById("not-on-list");
const onList = document.getElementById("on-list");
const listNameEl = document.getElementById("list-name");
const exportBtn = document.getElementById("export-btn");
const progress = document.getElementById("progress");
const progressText = document.getElementById("progress-text");
const result = document.getElementById("result");
const resultText = document.getElementById("result-text");

let currentEmail = "";
let cooldownInterval = null;
let cooldownSeconds = 0;
let otpSentAt = 0;

// ── Supabase OTP helpers ─────────────────────────────────
async function sendOtp(email) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/otp`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_ANON_KEY,
    },
    body: JSON.stringify({ email }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error_description || data.msg || "Failed to send code");
  }
}

async function verifyOtp(email, token) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_ANON_KEY,
    },
    body: JSON.stringify({ email, token, type: "email" }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error_description || data.msg || "Invalid code");
  }
  return data;
}

async function supabaseRefresh(refreshToken) {
  const res = await fetch(
    `${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ refresh_token: refreshToken }),
    },
  );
  const data = await res.json();
  if (!res.ok) throw new Error("Session expired. Please sign in again.");
  return data;
}

async function getSession() {
  const stored = await chrome.storage.local.get(["sb_session"]);
  if (!stored.sb_session) return null;

  const session = stored.sb_session;
  const expiresAt = session.expires_at * 1000;

  if (Date.now() > expiresAt - 60000) {
    try {
      const refreshed = await supabaseRefresh(session.refresh_token);
      await chrome.storage.local.set({ sb_session: refreshed });
      return refreshed;
    } catch {
      await chrome.storage.local.remove(["sb_session"]);
      return null;
    }
  }

  return session;
}

// ── Cooldown ─────────────────────────────────────────────
function startCooldown(sentAt) {
  otpSentAt = sentAt || Date.now();
  const elapsed = Math.floor((Date.now() - otpSentAt) / 1000);
  cooldownSeconds = Math.max(0, 60 - elapsed);
  if (cooldownSeconds <= 0) {
    resendBtn.disabled = false;
    resendBtn.textContent = "Resend code";
    return;
  }
  resendBtn.disabled = true;
  resendBtn.textContent = `Resend code (${cooldownSeconds}s)`;
  if (cooldownInterval) clearInterval(cooldownInterval);
  cooldownInterval = setInterval(() => {
    cooldownSeconds--;
    if (cooldownSeconds <= 0) {
      clearInterval(cooldownInterval);
      cooldownInterval = null;
      resendBtn.disabled = false;
      resendBtn.textContent = "Resend code";
    } else {
      resendBtn.textContent = `Resend code (${cooldownSeconds}s)`;
    }
  }, 1000);
}

// ── UI state ──────────────────────────────────────────────
function showEmailStep() {
  authEmailScreen.classList.remove("hidden");
  authCodeScreen.classList.add("hidden");
  mainScreen.classList.add("hidden");
  emailError.classList.add("hidden");
}

function showCodeStep() {
  authEmailScreen.classList.add("hidden");
  authCodeScreen.classList.remove("hidden");
  mainScreen.classList.add("hidden");
  codeError.classList.add("hidden");
  sentToEmail.textContent = currentEmail;
  otpCodeInput.value = "";
  otpCodeInput.focus();
}

function showMain(session) {
  authEmailScreen.classList.add("hidden");
  authCodeScreen.classList.add("hidden");
  mainScreen.classList.remove("hidden");
  userEmail.textContent = session.user.email;
}

// ── Check if on a Google Maps list page ───────────────────
async function checkCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (!tab?.url?.includes("google.com/maps")) {
      trackEvent("ext_page_check", { status: "not_on_list" });
      notOnList.classList.remove("hidden");
      onList.classList.add("hidden");
      return;
    }

    let listName = null;
    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: "GET_LIST_INFO",
      });
      if (chrome.runtime.lastError) { /* content script not injected */ }
      listName = response?.listName;
    } catch {
      // Content script might not be injected yet
    }

    if (listName) {
      listNameEl.textContent = listName;
    } else {
      listNameEl.textContent = "Google Maps List";
    }
    trackEvent("ext_page_check", { status: "on_list" });
    notOnList.classList.add("hidden");
    onList.classList.remove("hidden");
  } catch {
    notOnList.classList.remove("hidden");
    onList.classList.add("hidden");
  }
}

// ── Auth handlers ─────────────────────────────────────────
emailForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  emailError.classList.add("hidden");
  sendCodeBtn.disabled = true;
  sendCodeBtn.textContent = "Sending...";

  try {
    currentEmail = emailInput.value.trim().toLowerCase();
    await sendOtp(currentEmail);
    trackEvent("ext_otp_sent");
    otpSentAt = Date.now();
    await chrome.storage.local.set({ otp_pending: { email: currentEmail, sentAt: otpSentAt } });
    showCodeStep();
    startCooldown(otpSentAt);
  } catch (err) {
    trackEvent("ext_otp_error", { error: err.message });
    emailError.textContent = err.message;
    emailError.classList.remove("hidden");
  } finally {
    sendCodeBtn.disabled = false;
    sendCodeBtn.textContent = "Continue";
  }
});

codeForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  codeError.classList.add("hidden");
  verifyBtn.disabled = true;
  verifyBtn.textContent = "Verifying...";

  try {
    const token = otpCodeInput.value.trim();
    if (token.length < 6) {
      throw new Error("Please enter the full code.");
    }
    const session = await verifyOtp(currentEmail, token);
    trackEvent("ext_otp_verified");
    await chrome.storage.local.set({ sb_session: session });
    await chrome.storage.local.remove(["otp_pending"]);
    showMain(session);
    checkCurrentPage();
  } catch (err) {
    trackEvent("ext_otp_error", { error: err.message, stage: "verify" });
    codeError.textContent = err.message;
    codeError.classList.remove("hidden");
  } finally {
    verifyBtn.disabled = false;
    verifyBtn.textContent = "Verify";
  }
});

resendBtn.addEventListener("click", async () => {
  if (cooldownSeconds > 0) return;
  codeError.classList.add("hidden");
  try {
    await sendOtp(currentEmail);
    otpSentAt = Date.now();
    await chrome.storage.local.set({ otp_pending: { email: currentEmail, sentAt: otpSentAt } });
    startCooldown(otpSentAt);
  } catch (err) {
    codeError.textContent = err.message;
    codeError.classList.remove("hidden");
  }
});

changeEmailBtn.addEventListener("click", async () => {
  if (cooldownInterval) {
    clearInterval(cooldownInterval);
    cooldownInterval = null;
  }
  cooldownSeconds = 0;
  await chrome.storage.local.remove(["otp_pending"]);
  showEmailStep();
});

signOutBtn.addEventListener("click", async () => {
  trackEvent("ext_sign_out");
  await chrome.storage.local.remove(["sb_session"]);
  showEmailStep();
});

// ── Export handler ────────────────────────────────────────
exportBtn.addEventListener("click", async () => {
  const session = await getSession();
  if (!session) {
    showEmailStep();
    return;
  }

  trackEvent("ext_export_started");
  const exportStartTime = Date.now();
  exportBtn.disabled = true;
  onList.classList.add("hidden");
  progress.classList.remove("hidden");
  result.classList.add("hidden");

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    progressText.textContent = "Scrolling to load all places — please stay on this tab...";
    const scraped = await chrome.tabs.sendMessage(tab.id, {
      type: "SCRAPE_LIST",
    });

    if (!scraped?.places?.length) {
      throw new Error("No places found on this page");
    }

    trackEvent("ext_scrape_completed", { place_count: scraped.places.length });
    progressText.textContent = `Found ${scraped.places.length} places. Looking up addresses...`;

    // Connect a port to receive real-time enrichment progress
    const port = chrome.runtime.connect({ name: "enrichment-progress" });
    port.onMessage.addListener((msg) => {
      progressText.textContent = `Looking up ${msg.current}/${msg.total}: ${msg.placeName}`;
    });

    const uploadResult = await chrome.runtime.sendMessage({
      type: "UPLOAD_PLACES",
      listName: scraped.listName,
      places: scraped.places,
      accessToken: session.access_token,
      userId: session.user.id,
    });

    port.disconnect();

    if (uploadResult.error) {
      throw new Error(uploadResult.error);
    }

    trackEvent("ext_export_completed", {
      uploaded: uploadResult.uploaded,
      enriched: uploadResult.enriched,
      duration_ms: Date.now() - exportStartTime,
    });
    progress.classList.add("hidden");
    result.classList.remove("hidden");
    const enrichMsg = uploadResult.enriched != null
      ? ` (${uploadResult.enriched} with addresses)`
      : "";
    resultText.textContent = `Done! ${uploadResult.uploaded} places uploaded${enrichMsg}.`;
    resultText.className = "success";
  } catch (err) {
    trackEvent("ext_export_error", { error: err.message });
    progress.classList.add("hidden");
    result.classList.remove("hidden");
    // Better error guidance for "no places found"
    if (err.message === "No places found on this page") {
      resultText.textContent = "No places found. Make sure you've opened a specific saved list (not the main 'Saved' page). Try scrolling the list first, then retry.";
    } else {
      resultText.textContent = err.message;
    }
    resultText.className = "error";
    onList.classList.remove("hidden");
  } finally {
    exportBtn.disabled = false;
  }
});

// ── Re-check page when tab navigates (Google Maps is a SPA) ──
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    // Only re-check if we're on the main screen
    if (!mainScreen.classList.contains("hidden")) {
      checkCurrentPage();
    }
  }
});

// ── Init ──────────────────────────────────────────────────
(async () => {
  const session = await getSession();
  if (session) {
    showMain(session);
    checkCurrentPage();
    return;
  }

  // Restore OTP-pending state (popup may have closed while user checked email)
  const stored = await chrome.storage.local.get(["otp_pending"]);
  if (stored.otp_pending) {
    const { email, sentAt } = stored.otp_pending;
    // Only restore if OTP was sent within the last 10 minutes
    if (Date.now() - sentAt < 10 * 60 * 1000) {
      currentEmail = email;
      showCodeStep();
      startCooldown(sentAt);
      return;
    }
    // Expired — clear it
    await chrome.storage.local.remove(["otp_pending"]);
  }

  showEmailStep();
})();
