// Spotlyst Chrome Extension — Background (Service Worker)
// Handles Google Places enrichment, Supabase uploads, and dedup logic

const SUPABASE_URL = "https://ozedrhggdyenuatuvybc.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im96ZWRyaGdnZHllbnVhdHV2eWJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI1ODQ5MjEsImV4cCI6MjA4ODE2MDkyMX0.WvAhTNIPGQUOWO-gdtunjj2cd5TUu0ZOgC6y_tyaIho";
const GOOGLE_PLACES_API_KEY = "AIzaSyDII9UOVzLCUsfyAVqpDxtcRxfVpH1EB5E"; // Set this: same key as EXPO_PUBLIC_GOOGLE_PLACES_API_KEY

// ── Category mapping ──────────────────────────────────────
const RESTAURANT_TYPES = new Set([
  "restaurant",
  "food",
  "meal_delivery",
  "meal_takeaway",
  "bakery",
  "pizza_restaurant",
  "sandwich_shop",
  "seafood_restaurant",
  "steak_house",
  "sushi_restaurant",
  "ramen_restaurant",
  "chinese_restaurant",
  "indian_restaurant",
  "italian_restaurant",
  "japanese_restaurant",
  "korean_restaurant",
  "mexican_restaurant",
  "thai_restaurant",
  "vietnamese_restaurant",
  "mediterranean_restaurant",
  "middle_eastern_restaurant",
  "american_restaurant",
  "barbecue_restaurant",
  "brazilian_restaurant",
  "breakfast_restaurant",
  "brunch_restaurant",
  "fast_food_restaurant",
  "french_restaurant",
  "greek_restaurant",
  "hamburger_restaurant",
  "indonesian_restaurant",
  "lebanese_restaurant",
  "turkish_restaurant",
  "vegan_restaurant",
  "vegetarian_restaurant",
  "ice_cream_shop",
  // Scraped display text
  "pizza",
  "seafood",
  "steak",
  "sushi",
  "ramen",
  "chinese",
  "indian",
  "italian",
  "japanese",
  "korean",
  "mexican",
  "thai",
  "vietnamese",
  "mediterranean",
  "middle_eastern",
  "american",
  "barbecue",
  "bbq",
  "brazilian",
  "breakfast",
  "brunch",
  "fast_food",
  "french",
  "greek",
  "hamburger",
  "indonesian",
  "lebanese",
  "turkish",
  "vegan",
  "vegetarian",
  "sandwich",
  "californian",
  "peruvian",
  "cuban",
  "ethiopian",
  "hawaiian",
  "spanish",
  "tapas",
  "dim_sum",
  "noodle",
  "wings",
  "burgers",
  "tacos",
  "diner",
  "bistro",
  "gastropub",
  "soul_food",
]);

const BAR_TYPES = new Set([
  "bar",
  "night_club",
  "wine_bar",
  "cocktail_bar",
  "pub",
  "brewery",
  "beer_hall",
  "beer_garden",
  "sports_bar",
  "karaoke",
  "lounge",
  "cocktails",
  "wine",
]);

const COFFEE_TYPES = new Set([
  "cafe",
  "coffee_shop",
  "tea_house",
  "juice_shop",
  "bubble_tea_store",
  "coffee",
  "tea",
  "juice",
  "bubble_tea",
  "boba",
]);

function categoryFromGoogleType(type) {
  if (!type) return null;
  const t = type.toLowerCase().replace(/\s+/g, "_");
  if (RESTAURANT_TYPES.has(t)) return "restaurant";
  if (BAR_TYPES.has(t)) return "bar";
  if (COFFEE_TYPES.has(t)) return "coffee_shop";
  return null;
}

// Try multiple type strings (primaryType first, then each type in types array)
function categoryFromTypes(primaryType, typesArray) {
  const cat = categoryFromGoogleType(primaryType);
  if (cat) return cat;
  if (typesArray) {
    for (const t of typesArray) {
      const c = categoryFromGoogleType(t);
      if (c) return c;
    }
  }
  return null;
}

// ── Google Places API enrichment ──────────────────────────
async function enrichPlace(place) {
  if (!GOOGLE_PLACES_API_KEY) return place; // Skip if no key configured

  try {
    const query = [place.name, place.address].filter(Boolean).join(", ");

    const res = await fetch(
      "https://places.googleapis.com/v1/places:searchText",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": GOOGLE_PLACES_API_KEY,
          "X-Goog-FieldMask":
            "places.id,places.formattedAddress,places.location,places.types,places.primaryType,places.displayName",
        },
        body: JSON.stringify({
          textQuery: query,
          maxResultCount: 1,
        }),
      },
    );

    if (!res.ok) {
      console.warn(
        `[Spotlyst] Places API error for "${place.name}": ${res.status}`,
      );
      return place;
    }

    const data = await res.json();
    const match = data.places?.[0];
    if (!match) return place;

    return {
      ...place,
      address: match.formattedAddress || place.address,
      google_place_id: match.id || place.google_place_id,
      google_type: match.primaryType || place.google_type,
      google_types: match.types || null,
      latitude: match.location?.latitude ?? place.latitude,
      longitude: match.location?.longitude ?? place.longitude,
    };
  } catch (err) {
    console.warn(
      `[Spotlyst] Places API error for "${place.name}":`,
      err.message,
    );
    return place;
  }
}

async function enrichAllPlaces(places, onProgress) {
  if (!GOOGLE_PLACES_API_KEY) {
    console.log("[Spotlyst] No GOOGLE_PLACES_API_KEY set, skipping enrichment");
    return places;
  }

  console.log(
    `[Spotlyst] Enriching ${places.length} places via Google Places API...`,
  );
  const enriched = [];

  for (let i = 0; i < places.length; i++) {
    const result = await enrichPlace(places[i]);
    enriched.push(result);

    if (onProgress) onProgress(i + 1, places.length);

    // Rate limit: ~3 requests/sec to stay well under quota
    if (i < places.length - 1) {
      await new Promise((r) => setTimeout(r, 350));
    }
  }

  console.log("[Spotlyst] Enrichment complete");
  return enriched;
}

// ── Supabase REST helpers ─────────────────────────────────
async function supabaseQuery(
  path,
  { method = "GET", body, accessToken, params } = {},
) {
  const url = new URL(`${SUPABASE_URL}/rest/v1/${path}`);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      url.searchParams.set(k, v);
    }
  }

  const headers = {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${accessToken}`,
    "Content-Type": "application/json",
    Prefer: method === "POST" ? "return=representation" : "",
  };

  const res = await fetch(url.toString(), {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `Supabase error: ${res.status}`);
  }

  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

// ── Progress reporting ────────────────────────────────────
// The popup connects via a port to receive real-time enrichment progress.
let progressPort = null;

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "enrichment-progress") {
    progressPort = port;
    port.onDisconnect.addListener(() => {
      progressPort = null;
    });
  }
});

function sendProgress(current, total, placeName) {
  if (progressPort) {
    try {
      progressPort.postMessage({ current, total, placeName });
    } catch {
      progressPort = null;
    }
  }
}

// ── Upload handler ────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== "UPLOAD_PLACES") return false;

  (async () => {
    try {
      const { listName, places, accessToken, userId } = msg;

      // 1. Enrich places via Google Places API (adds address, coords, type)
      const enrichedPlaces = await enrichAllPlaces(places, (current, total) => {
        const placeName = places[current - 1]?.name || "";
        sendProgress(current, total, placeName);
      });

      // 2. Fetch existing places for dedup (by google_place_id AND name)
      const existingPlaces = await supabaseQuery("places", {
        accessToken,
        params: {
          select: "id,google_place_id,name",
          user_id: `eq.${userId}`,
        },
      });

      const existingByPlaceId = new Map();
      const existingByName = new Map();
      for (const p of existingPlaces || []) {
        if (p.google_place_id) {
          existingByPlaceId.set(p.google_place_id, p.id);
        }
        existingByName.set(p.name.toLowerCase(), p.id);
      }

      function findDuplicate(p) {
        if (p.google_place_id && existingByPlaceId.has(p.google_place_id)) {
          return existingByPlaceId.get(p.google_place_id);
        }
        if (existingByName.has(p.name.toLowerCase())) {
          return existingByName.get(p.name.toLowerCase());
        }
        return null;
      }

      // 3. Create import job
      const pendingPlaces = enrichedPlaces.filter((p) => !findDuplicate(p));

      const [job] = await supabaseQuery("import_jobs", {
        method: "POST",
        accessToken,
        body: {
          user_id: userId,
          source_list_name: listName,
          total_count: enrichedPlaces.length,
          pending_count: pendingPlaces.length,
          status: "pending",
        },
      });

      // 4. Build staging rows
      const stagingRows = enrichedPlaces.map((p) => {
        const existingId = findDuplicate(p);
        const category = categoryFromTypes(p.google_type, p.google_types);
        return {
          job_id: job.id,
          user_id: userId,
          name: p.name,
          address: p.address,
          notes: p.notes || null,
          google_place_id: p.google_place_id,
          google_type: p.google_type,
          latitude: p.latitude,
          longitude: p.longitude,
          suggested_category: category,
          status: existingId ? "duplicate" : "pending",
          existing_place_id: existingId || null,
        };
      });

      // 5. Batch insert staging rows
      await supabaseQuery("import_staging", {
        method: "POST",
        accessToken,
        body: stagingRows,
      });

      const enrichedCount = enrichedPlaces.filter(
        (p) => p.latitude && p.longitude,
      ).length;
      sendResponse({
        uploaded: enrichedPlaces.length,
        enriched: enrichedCount,
        jobId: job.id,
      });
    } catch (err) {
      console.error("[Spotlyst] Upload error:", err);
      sendResponse({ error: err.message });
    }
  })();

  return true; // Keep channel open for async
});
