// Spotlyst Chrome Extension — Content Script
// Runs on Google Maps pages; scrapes saved list data when triggered

// ── Helpers ───────────────────────────────────────────────
function extractPlaceIdFromUrl(href) {
  if (!href) return null;
  // ChIJ format place IDs
  const chijMatch = href.match(/!1s(ChIJ[A-Za-z0-9_-]+)/);
  if (chijMatch) return chijMatch[1];
  // Hex place IDs (0x format)
  const hexMatch = href.match(/!1s(0x[0-9a-f]+:0x[0-9a-f]+)/i);
  if (hexMatch) return hexMatch[1];
  // Place ID in /place/ URL segment encoded
  const placeMatch = href.match(/\/maps\/place\/[^/]+\/data=.*!1s([^!]+)/);
  if (placeMatch) return decodeURIComponent(placeMatch[1]);
  return null;
}

function extractCoordsFromUrl(href) {
  if (!href) return null;
  // @lat,lng,zoom
  const atMatch = href.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
  if (atMatch) return { lat: parseFloat(atMatch[1]), lng: parseFloat(atMatch[2]) };
  // !3dlat!4dlng
  const bangMatch = href.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
  if (bangMatch) return { lat: parseFloat(bangMatch[1]), lng: parseFloat(bangMatch[2]) };
  // !8m2!3dlat!4dlng
  const bang8Match = href.match(/!8m2!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
  if (bang8Match) return { lat: parseFloat(bang8Match[1]), lng: parseFloat(bang8Match[2]) };
  return null;
}

// ── List name detection ───────────────────────────────────
function getListName() {
  // Strategy 1: h1 or h2 with headline-like classes
  const headlineSelectors = [
    'h1.fontHeadlineLarge',
    'h1[class*="fontHeadline"]',
    'h2[class*="fontHeadline"]',
    'div.fontHeadlineLarge',
    'span.fontHeadlineLarge',
  ];
  for (const sel of headlineSelectors) {
    const el = document.querySelector(sel);
    const text = el?.textContent?.trim();
    if (text && text.length > 1 && text.length < 200) return text;
  }

  // Strategy 2: Any h1 in the left panel (not the main map area)
  const sidePanel = document.querySelector('div[role="main"]')
    || document.querySelector('div.bJzME')
    || document.querySelector('#QA0Szd');
  if (sidePanel) {
    const h1 = sidePanel.querySelector('h1');
    const text = h1?.textContent?.trim();
    if (text && text.length > 1) return text;
  }

  // Strategy 3: Look for any h1 on page
  const allH1s = document.querySelectorAll('h1');
  for (const h1 of allH1s) {
    const text = h1.textContent?.trim();
    if (text && text.length > 1 && text !== 'Google Maps') return text;
  }

  // Strategy 4: Aria label on header region
  const header = document.querySelector('[role="banner"] h1, [role="heading"][aria-level="1"]');
  if (header?.textContent?.trim()) return header.textContent.trim();

  return null;
}

// ── Find scrollable list container ────────────────────────
function findScrollContainer() {
  // Try common scrollable containers
  const candidates = [
    document.querySelector('div[role="feed"]'),
    document.querySelector('div.m6QErb.WNBkOb'),
    document.querySelector('div.m6QErb'),
    document.querySelector('div.section-scrollbox'),
    // Generic: find scrollable div in the side panel
    document.querySelector('#QA0Szd div[style*="overflow"]'),
  ];

  for (const el of candidates) {
    if (el) return el;
  }

  // Fallback: find any tall scrollable div in the left portion of the page
  const allDivs = document.querySelectorAll('div');
  for (const div of allDivs) {
    const rect = div.getBoundingClientRect();
    const style = window.getComputedStyle(div);
    if (
      rect.left < 500 &&
      rect.height > 300 &&
      div.scrollHeight > div.clientHeight + 50 &&
      (style.overflowY === 'auto' || style.overflowY === 'scroll')
    ) {
      return div;
    }
  }

  return null;
}

// ── Collect places from currently visible cards ──────────
function collectVisiblePlaces(accumulator) {
  const nameEls = document.querySelectorAll('div.fontHeadlineSmall');
  for (const nameEl of nameEls) {
    const name = nameEl?.textContent?.trim();
    if (!name || accumulator.has(name)) continue;

    // Walk up to find the card container
    const card = nameEl.closest('div.BsJqK') || nameEl.closest('button.SMP2wb')
      || nameEl.closest('div.ZSOIif') || nameEl.parentElement?.parentElement;
    if (!card) continue;

    let address = null;
    let googleType = null;
    let notes = null;

    const allText = card.querySelectorAll('span, div');
    for (const el of allText) {
      if (el.children.length > 0) continue;
      const text = el.textContent?.trim();
      if (!text || text.length < 2 || text === name) continue;
      if (/^[\d.]+$/.test(text)) continue;
      if (/^\([\d,]+\)$/.test(text)) continue;
      if (/^\$/.test(text)) continue;
      if (text === '·' || text === '•') continue;

      if (!googleType && /restaurant|pizza|burger|cafe|coffee|bar|food|mexican|italian|chinese|japanese|korean|thai|indian|french|greek|american|seafood|steak|bakery|deli|sushi|ramen|vietnamese|mediterranean|brunch|breakfast|fast food|californian|bbq/i.test(text)) {
        googleType = text.toLowerCase().replace(/\s+/g, '_');
        continue;
      }
      if (!address && text.length > 5) {
        address = text;
      }
    }

    // Notes
    const cardParent = card.parentElement;
    const textarea = cardParent?.querySelector('textarea') || card.querySelector('textarea');
    if (textarea?.value?.trim()) {
      notes = textarea.value.trim();
    }
    if (!notes) {
      const noteSelectors = ['div[class*="note"] span', 'span[class*="note"]', 'div.fontBodyMedium textarea'];
      for (const sel of noteSelectors) {
        const el = cardParent?.querySelector(sel) || card.querySelector(sel);
        const text = el?.textContent?.trim() || el?.value?.trim();
        if (text && text !== '+ Note' && text !== 'Add a note') {
          notes = text;
          break;
        }
      }
    }

    accumulator.set(name, {
      name,
      address,
      notes,
      google_place_id: null,
      google_type: googleType,
      latitude: null,
      longitude: null,
    });
  }
}

// ── Auto-scroll to load all places ────────────────────────
async function scrollAndCollectAll() {
  // Google Maps virtualizes the list — only ~20 items exist in the DOM at once.
  // We must collect place data AS we scroll, before items are removed.
  const scrollable = findScrollContainer();
  if (!scrollable) {
    console.log('[Spotlyst] No scrollable container found');
    return new Map();
  }

  const candidates = [scrollable];
  for (const child of scrollable.querySelectorAll('div')) {
    if (child.scrollHeight > child.clientHeight + 100) {
      candidates.push(child);
    }
  }

  console.log(`[Spotlyst] Found ${candidates.length} scroll candidate(s), loading all places...`);

  const collected = new Map();
  let lastCollectedCount = 0;
  let staleCount = 0;
  const maxStale = 12; // Extra patience for large lists

  // Collect what's already visible
  collectVisiblePlaces(collected);
  console.log(`[Spotlyst] Initial collection: ${collected.size} places`);

  while (staleCount < maxStale) {
    // Use 'instant' — 'smooth' gets throttled when tab loses focus
    for (const el of candidates) {
      el.scrollBy({ top: 400, behavior: 'instant' });
    }
    // Short delay for DOM to update with new virtualized items
    await new Promise((r) => setTimeout(r, 600));

    // Collect newly visible cards
    collectVisiblePlaces(collected);

    if (collected.size === lastCollectedCount) {
      staleCount++;
      // On stale iterations, try a bigger scroll to unstick
      if (staleCount >= 3) {
        for (const el of candidates) {
          el.scrollBy({ top: 1200, behavior: 'instant' });
        }
        await new Promise((r) => setTimeout(r, 800));
        collectVisiblePlaces(collected);
      }
      console.log(`[Spotlyst] Scroll: ${collected.size} places collected (stale ${staleCount}/${maxStale})`);
    } else {
      console.log(`[Spotlyst] Scroll: ${lastCollectedCount} → ${collected.size} places collected`);
      staleCount = 0;
      lastCollectedCount = collected.size;
    }
  }

  console.log(`[Spotlyst] Finished scrolling, ${collected.size} total places collected`);
  return collected;
}

// ── Extract place type from card text ─────────────────────
function extractTypeFromCard(card) {
  // Look for type indicators: "Pizza", "Restaurant", "Fast Food", "Mexican", etc.
  // These usually appear as short text segments after the rating/price info
  const allText = card.querySelectorAll('span, div');
  for (const el of allText) {
    if (el.children.length > 0) continue; // Only leaf nodes
    const text = el.textContent?.trim();
    if (!text || text.length > 30 || text.length < 3) continue;
    // Skip if it's a number (rating), price ($), or contains special chars
    if (/^[\d.]+$/.test(text)) continue;
    if (/^\$/.test(text)) continue;
    if (/^\([\d,]+\)$/.test(text)) continue; // review count like (325)
    if (text.includes('·')) continue;
    // Likely a type/cuisine
    if (/restaurant|pizza|burger|cafe|coffee|bar|food|mexican|italian|chinese|japanese|korean|thai|indian|french|greek|american|seafood|steak|bakery|deli|sushi|ramen|vietnamese|mediterranean|brunch|breakfast/i.test(text)) {
      return text.toLowerCase().replace(/\s+/g, '_');
    }
  }
  return null;
}

// ── DOM diagnostic dump ───────────────────────────────────
function dumpDiagnostics() {
  console.log('[Spotlyst] === DOM DIAGNOSTICS ===');

  // All <a> tags and their hrefs
  const allLinks = document.querySelectorAll('a[href]');
  const mapsLinks = [];
  for (const a of allLinks) {
    const href = a.getAttribute('href') || '';
    if (href.includes('maps')) {
      mapsLinks.push({ href: href.substring(0, 150), ariaLabel: a.getAttribute('aria-label'), tag: a.tagName });
    }
  }
  console.log(`[Spotlyst] Total <a> on page: ${allLinks.length}, maps-related: ${mapsLinks.length}`);
  console.log('[Spotlyst] First 10 maps links:', JSON.stringify(mapsLinks.slice(0, 10), null, 2));

  // Elements with role="feed"
  const feeds = document.querySelectorAll('[role="feed"]');
  console.log(`[Spotlyst] Elements with role="feed": ${feeds.length}`);
  feeds.forEach((f, i) => {
    console.log(`[Spotlyst]   feed[${i}]: children=${f.children.length}, tag=${f.tagName}, class="${f.className.substring(0, 80)}"`);
  });

  // Scrollable containers
  const scrollContainer = findScrollContainer();
  if (scrollContainer) {
    console.log(`[Spotlyst] Scroll container: tag=${scrollContainer.tagName}, class="${scrollContainer.className.substring(0, 80)}", children=${scrollContainer.children.length}`);
    // Log first 3 children structure
    for (let i = 0; i < Math.min(3, scrollContainer.children.length); i++) {
      const child = scrollContainer.children[i];
      console.log(`[Spotlyst]   child[${i}]: tag=${child.tagName}, class="${child.className.substring(0, 80)}", innerHTML=${child.innerHTML.substring(0, 200)}`);
    }
  } else {
    console.log('[Spotlyst] No scroll container found!');
  }

  // Look for text content matching known place names from the screenshot
  const body = document.body.innerText;
  const testNames = ['Ghisallo', 'Forage', "Sonny's"];
  for (const name of testNames) {
    const found = body.includes(name);
    console.log(`[Spotlyst] Text "${name}" found on page: ${found}`);
    if (found) {
      // Find the element containing this text
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        if (walker.currentNode.textContent.includes(name)) {
          const el = walker.currentNode.parentElement;
          console.log(`[Spotlyst]   "${name}" is in: <${el.tagName} class="${el.className.substring(0, 60)}"> parent=<${el.parentElement?.tagName} class="${el.parentElement?.className.substring(0, 60)}">`);
          // Walk up 5 levels to show DOM tree
          let ancestor = el;
          for (let j = 0; j < 5 && ancestor; j++) {
            const aTag = ancestor.tagName === 'A' ? ` href="${ancestor.getAttribute('href')?.substring(0, 100)}"` : '';
            console.log(`[Spotlyst]     ${'  '.repeat(j)}↑ <${ancestor.tagName} class="${ancestor.className.substring(0, 50)}"${aTag}>`);
            ancestor = ancestor.parentElement;
          }
          break;
        }
      }
    }
  }

  console.log('[Spotlyst] === END DIAGNOSTICS ===');
}

// ── Scrape all place cards ────────────────────────────────
function scrapePlaces() {
  const places = [];
  const seen = new Set();

  console.log('[Spotlyst] Starting scrape...');

  // Google Maps saved lists use <button> cards, not <a> links.
  // Structure: div.BsJqK > div.ZSOIif > button.SMP2wb > div.H1bDYe > div.fontHeadlineSmall
  // Try multiple selectors for the card container.
  const cardSelectors = [
    'div.BsJqK',                     // Observed wrapper
    'div.ZSOIif',                     // Inner wrapper
    'button.SMP2wb',                  // The button itself
  ];

  let cards = [];
  for (const sel of cardSelectors) {
    cards = document.querySelectorAll(sel);
    console.log(`[Spotlyst] Selector "${sel}": ${cards.length} elements`);
    if (cards.length > 0) break;
  }

  // Fallback: find all elements containing div.fontHeadlineSmall (the name element)
  if (cards.length === 0) {
    const nameEls = document.querySelectorAll('div.fontHeadlineSmall');
    console.log(`[Spotlyst] Fallback (div.fontHeadlineSmall parents): ${nameEls.length}`);
    // Use the button ancestor as the card
    const cardSet = new Set();
    for (const el of nameEls) {
      const btn = el.closest('button') || el.closest('div[class*="BsJqK"]') || el.parentElement?.parentElement;
      if (btn) cardSet.add(btn);
    }
    cards = Array.from(cardSet);
  }

  console.log(`[Spotlyst] Processing ${cards.length} cards`);

  for (const card of cards) {
    try {
      // ── Name ──
      const nameEl = card.querySelector('div.fontHeadlineSmall')
        || card.querySelector('div[class*="fontHeadlineSmall"]');
      const name = nameEl?.textContent?.trim();
      if (!name) continue;

      // Deduplicate by name
      if (seen.has(name)) continue;
      seen.add(name);

      // ── Address / extra info ──
      // Text segments in the card that aren't the name, rating, or price
      let address = null;
      let googleType = null;
      const allText = card.querySelectorAll('span, div');
      for (const el of allText) {
        if (el.children.length > 0) continue; // Only leaf text nodes
        const text = el.textContent?.trim();
        if (!text || text.length < 2 || text === name) continue;
        // Skip rating numbers, review counts, price, dots
        if (/^[\d.]+$/.test(text)) continue;
        if (/^\([\d,]+\)$/.test(text)) continue;
        if (/^\$/.test(text)) continue;
        if (text === '·' || text === '•') continue;

        // Detect cuisine/type keywords
        if (!googleType && /restaurant|pizza|burger|cafe|coffee|bar|food|mexican|italian|chinese|japanese|korean|thai|indian|french|greek|american|seafood|steak|bakery|deli|sushi|ramen|vietnamese|mediterranean|brunch|breakfast|fast food|californian|bbq/i.test(text)) {
          googleType = text.toLowerCase().replace(/\s+/g, '_');
          continue;
        }

        // Address-like text (longer, may contain digits or commas)
        if (!address && text.length > 5) {
          address = text;
        }
      }

      // ── Notes ──
      // Google Maps shows user notes as a textarea or text element near the card.
      // Look for note content in the card's parent/sibling area.
      let notes = null;
      const cardParent = card.parentElement;

      // Check for textarea (editable note field)
      const textarea = cardParent?.querySelector('textarea')
        || card.querySelector('textarea');
      if (textarea?.value?.trim()) {
        notes = textarea.value.trim();
      }

      // Check for note display elements (when note exists but isn't being edited)
      if (!notes) {
        const noteSelectors = [
          'div[class*="note"] span',
          'span[class*="note"]',
          'div.fontBodyMedium textarea',
        ];
        for (const sel of noteSelectors) {
          const el = cardParent?.querySelector(sel) || card.querySelector(sel);
          const text = el?.textContent?.trim() || el?.value?.trim();
          if (text && text !== '+ Note' && text !== 'Add a note') {
            notes = text;
            break;
          }
        }
      }

      if (notes) {
        console.log(`[Spotlyst] Note found for "${name}": "${notes}"`);
      }

      places.push({
        name,
        address,
        notes,
        google_place_id: null,
        google_type: googleType,
        latitude: null,
        longitude: null,
      });
    } catch (err) {
      console.warn('[Spotlyst] Error processing card:', err);
    }
  }

  console.log(`[Spotlyst] Scraped ${places.length} places`);
  return places;
}

// ── Message handler ───────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "GET_LIST_INFO") {
    const listName = getListName();
    console.log('[Spotlyst] GET_LIST_INFO:', listName);
    sendResponse({ listName });
    return true;
  }

  if (msg.type === "SCRAPE_LIST") {
    (async () => {
      try {
        const collected = await scrollAndCollectAll();
        const places = Array.from(collected.values());
        const listName = getListName() || "Unnamed List";
        console.log(`[Spotlyst] SCRAPE_LIST complete: "${listName}", ${places.length} places`);
        sendResponse({ listName, places });
      } catch (err) {
        console.error('[Spotlyst] SCRAPE_LIST error:', err);
        sendResponse({ listName: null, places: [] });
      }
    })();
    return true; // Keep channel open for async response
  }

  return false;
});
